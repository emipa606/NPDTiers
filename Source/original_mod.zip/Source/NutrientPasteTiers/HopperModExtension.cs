﻿using System;
using System.Collections.Generic;
using Verse;
using RimWorld;
using UnityEngine;

namespace NutrientPasteTiers
{
    public class HopperCustom : DefModExtension
    {
        public float setTemperature;
        //Can add more

    }
}